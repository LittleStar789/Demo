﻿namespace AvtSystem
{
    partial class AuthorizateForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            login_textBox = new TextBox();
            password_textBox = new TextBox();
            log_in = new Button();
            SuspendLayout();
            // 
            // login_textBox
            // 
            login_textBox.Location = new Point(263, 131);
            login_textBox.Name = "login_textBox";
            login_textBox.Size = new Size(150, 31);
            login_textBox.TabIndex = 0;
            // 
            // password_textBox
            // 
            password_textBox.Location = new Point(263, 185);
            password_textBox.Name = "password_textBox";
            password_textBox.Size = new Size(150, 31);
            password_textBox.TabIndex = 1;
            // 
            // log_in
            // 
            log_in.Location = new Point(283, 240);
            log_in.Name = "log_in";
            log_in.Size = new Size(112, 34);
            log_in.TabIndex = 2;
            log_in.Text = "Войти";
            log_in.UseVisualStyleBackColor = true;
            log_in.Click += log_in_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(log_in);
            Controls.Add(password_textBox);
            Controls.Add(login_textBox);
            Name = "Form1";
            Text = "Окно регистрации";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox login_textBox;
        private TextBox password_textBox;
        private Button log_in;
    }
}