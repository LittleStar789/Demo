using AvtSystem.ModelEF;

namespace AvtSystem
{
    public partial class AuthorizateForm : Form
    {
        public AuthorizateForm()
        {
            InitializeComponent();
        }
        private decimal? _userId = null;
        private string _roleName = "No authorized";
        private string? _userName = null; 

        private void log_in_Click(object sender, EventArgs e)
        {
            string login = login_textBox.Text;
            string password = password_textBox.Text;

            try
            {
                using (var dbContext = new DemodbContext())
                {
                    var userData = dbContext.Users
                        .FirstOrDefault(user => user.Password == password && user.Login == login);
                    if (userData != null)
                    {
                        _userId = userData.Id;
                        _userName = userData.FirstName;
                    }

                    var roleId = dbContext.Users
                        .First(user => user.Id == _userId).IdRole;
                    _roleName = dbContext.Roles
                        .First(role => role.Id == roleId).RoleName;
                }
                MessageBox.Show("�� ����� ��� " + _roleName);
                LoadMainForms();
            }
            catch (Exception ex)
            {
                MessageBox.Show("���������� ��� ���!\n\n" + ex.ToString());
            }
        }
        /// <summary>
        /// ����� �������� �� ������� ����� �� ����
        /// </summary>
        private void LoadMainForms()
        {
            switch(_roleName)
            {
                case "Client              ":
                    ClientForm cForm = new ClientForm(this, _userName, _userId);
                    cForm.Show();
                    break;
                case "Manager":
                    //
                    break;
                case "Admin               ":
                    //
                    break;
                case "Technician          ":
                    //
                    break;
                    default:
                    //
                    break;


            }
        }
    }
}