﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AvtSystem
{
    public partial class ClientForm : Form
    {
        private AuthorizateForm _authForm;

        public ClientForm(AuthorizateForm authorizateForm, string? userName, decimal? userId)
        {
            InitializeComponent();
            _authForm = authorizateForm;
            _authForm.Hide();
            label1.Text = "Текущий пользователь: " + userName;


        }

        private void AddApplicationBtn_Click(object sender, EventArgs e)
        {
            NewOrderForm newOrderForm = new NewOrderForm();
            newOrderForm.Show();
        }
    }
}
