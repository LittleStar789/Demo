﻿using System;
using System.Collections.Generic;

namespace AvtSystem.ModelEF;

public partial class EquipmentType
{
    public int Id { get; set; }

    public string EquipmentType1 { get; set; } = null!;

    public virtual ICollection<Order> Orders { get; set; } = new List<Order>();

    public virtual ICollection<Technician> TechnicianIdTypeEquipment1Navigations { get; set; } = new List<Technician>();

    public virtual ICollection<Technician> TechnicianIdTypeEquipment2Navigations { get; set; } = new List<Technician>();

    public virtual ICollection<Technician> TechnicianIdTypeEquipment3Navigations { get; set; } = new List<Technician>();
}
