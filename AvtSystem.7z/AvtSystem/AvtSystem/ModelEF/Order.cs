﻿using System;
using System.Collections.Generic;

namespace AvtSystem.ModelEF;

public partial class Order
{
    public int Id { get; set; }

    public int IdClient { get; set; }

    public int IdTypeEquipment { get; set; }

    public int IdTypeProblem { get; set; }

    public int IdTechnician { get; set; }

    public int IdManager { get; set; }

    public int IdStatus { get; set; }

    public DateTime DateOrderOpen { get; set; }

    public DateTime DateOrderClose { get; set; }

    public string Comments { get; set; } = null!;

    public string Photo { get; set; } = null!;

    public virtual User IdClientNavigation { get; set; } = null!;

    public virtual User IdManagerNavigation { get; set; } = null!;

    public virtual Status IdStatusNavigation { get; set; } = null!;

    public virtual Technician IdTypeEquipment1 { get; set; } = null!;

    public virtual EquipmentType IdTypeEquipmentNavigation { get; set; } = null!;

    public virtual ProblemType IdTypeProblemNavigation { get; set; } = null!;
}
