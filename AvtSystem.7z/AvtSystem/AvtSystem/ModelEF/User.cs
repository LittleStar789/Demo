﻿using System;
using System.Collections.Generic;

namespace AvtSystem.ModelEF;

public partial class User
{
    public int Id { get; set; }

    public string Login { get; set; } = null!;

    public string Password { get; set; } = null!;

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string Nickname { get; set; } = null!;

    public string Mail { get; set; } = null!;

    public int Phone { get; set; }

    public DateTime RegisterDate { get; set; }

    public int IdRole { get; set; }

    public virtual Role IdRoleNavigation { get; set; } = null!;

    public virtual ICollection<Order> OrderIdClientNavigations { get; set; } = new List<Order>();

    public virtual ICollection<Order> OrderIdManagerNavigations { get; set; } = new List<Order>();

    public virtual ICollection<Technician> Technicians { get; set; } = new List<Technician>();
}
