﻿namespace AvtSystem
{
    partial class NewOrderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            equipmentTypes_comboBox = new ComboBox();
            problemTypes_comboBox = new ComboBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            dataGridView1 = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // equipmentTypes_comboBox
            // 
            equipmentTypes_comboBox.FormattingEnabled = true;
            equipmentTypes_comboBox.Location = new Point(214, 98);
            equipmentTypes_comboBox.Name = "equipmentTypes_comboBox";
            equipmentTypes_comboBox.Size = new Size(182, 33);
            equipmentTypes_comboBox.TabIndex = 0;
            // 
            // problemTypes_comboBox
            // 
            problemTypes_comboBox.FormattingEnabled = true;
            problemTypes_comboBox.Location = new Point(214, 152);
            problemTypes_comboBox.Name = "problemTypes_comboBox";
            problemTypes_comboBox.Size = new Size(182, 33);
            problemTypes_comboBox.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(214, 61);
            label1.Name = "label1";
            label1.Size = new Size(197, 25);
            label1.TabIndex = 2;
            label1.Text = "Добавить новый заказ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(41, 101);
            label2.Name = "label2";
            label2.Size = new Size(167, 25);
            label2.TabIndex = 3;
            label2.Text = "Тип оборудования";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(54, 152);
            label3.Name = "label3";
            label3.Size = new Size(132, 25);
            label3.TabIndex = 4;
            label3.Text = "Тип проблемы";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 213);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.RowTemplate.Height = 33;
            dataGridView1.Size = new Size(1136, 225);
            dataGridView1.TabIndex = 5;
            // 
            // NewOrderForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1160, 450);
            Controls.Add(dataGridView1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(problemTypes_comboBox);
            Controls.Add(equipmentTypes_comboBox);
            Name = "NewOrderForm";
            Text = "NewOrderForm";
            Load += NewOrderForm_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox equipmentTypes_comboBox;
        private ComboBox problemTypes_comboBox;
        private Label label1;
        private Label label2;
        private Label label3;
        private DataGridView dataGridView1;
    }
}