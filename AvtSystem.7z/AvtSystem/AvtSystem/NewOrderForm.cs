﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AvtSystem
{
    public partial class NewOrderForm : Form
    {
        public NewOrderForm()
        {
            InitializeComponent();
        }

        private void NewOrderForm_Load(object sender, EventArgs e)
        {
            using (var dbContext = new DemodbContext())
            {
                var selectedTypes = from type in dbContext.EquipmentTypes select type.EquipmentType1;
                equipmentTypes_comboBox.Items.AddRange(selectedTypes.ToArray());
                equipmentTypes_comboBox.SelectedIndex = 1;

                var selectedProblems = from pb in dbContext.ProblemTypes select pb.ProblemType1;
                problemTypes_comboBox.Items.AddRange(selectedProblems.ToArray());
                problemTypes_comboBox.SelectedIndex = 1;

                dataGridView1.DataSource = dbContext.Users.ToArray();
            }
        }
    }
}
